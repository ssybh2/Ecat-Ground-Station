"""AIM EtherCAT desktop configuration and commissioning station."""
__version__ = "0.2.1"
